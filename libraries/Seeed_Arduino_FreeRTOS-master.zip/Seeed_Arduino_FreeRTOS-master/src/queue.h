#ifndef _ARDUINO_QUEUE_H_
#define _ARDUINO_QUEUE_H_

#include "../FreeRTOS/Source/include/queue.h"

#endif //_ARDUINO_QUEUE_H_
