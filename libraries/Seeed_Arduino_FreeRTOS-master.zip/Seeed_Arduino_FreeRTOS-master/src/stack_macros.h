#ifndef _ARDUINO_STACK_MACROS_H_
#define _ARDUINO_STACK_MACROS_H_

#include "../FreeRTOS/Source/include/stack_macros.h"

#endif //_ARDUINO_STACK_MACROS_H_
