#ifndef _ARDUINO_FREERTOS_H_
#define _ARDUINO_FREERTOS_H_

#include "../FreeRTOS/Source/include/FreeRTOS.h"

#endif //_ARDUINO_FREERTOS_H_
