#ifndef _ARDUINO_MESSAGE_BUFFER_H_
#define _ARDUINO_MESSAGE_BUFFER_H_

#include "../FreeRTOS/Source/include/message_buffer.h"

#endif //_ARDUINO_MESSAGE_BUFFER_H_
