#ifndef _ARDUINO_MPU_PROTOTYPES_H_
#define _ARDUINO_MPU_PROTOTYPES_H_

/* MPU not supported */
/*#include "FreeRTOS/Source/include/mpu_prototypes.h"*/

#endif //_ARDUINO_MPU_PROTOTYPES_H_
