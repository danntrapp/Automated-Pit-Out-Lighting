#ifndef _ARDUINO_STREAM_BUFFER_H_
#define _ARDUINO_STREAM_BUFFER_H_

#include "../FreeRTOS/Source/include/stream_buffer.h"

#endif //_ARDUINO_STREAM_BUFFER_H_
