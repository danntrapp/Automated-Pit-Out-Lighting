#ifndef _ARDUINO_SEMPHR_H_
#define _ARDUINO_SEMPHR_H_

#include "../FreeRTOS/Source/include/semphr.h"

#endif //_ARDUINO_SEMPHR_H_
